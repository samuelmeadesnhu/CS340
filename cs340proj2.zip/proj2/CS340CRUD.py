from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:53780' % (username, password))
        # where xxxx is your unique port number
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            insert = self.database.animals.insert(data) # run insert and store return
            if insert != 0: # check insert was successful
                return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
        return False

# Create method to implement the R in CRUD. 
    def read(self, data):
        if data is not None:
            return self.database.animals.find(data, {'_id': False})
            #return self.database.animals.find(data)
        else:
            raise Exception("Nothing to read, because data parameter is empty")
            
    def update(self, data, newData):
        if data is not None and newData is not None:
            update = self.database.animals.update_many(data, newData)
            if update.modified_count != 0:
                return newData
            else:
                return "Error updating"
        else:
            raise Exception("Nothing to read, because data parameter is empty")

    def delete(self, data):
        if data is not None:
            result = self.database.animals.delete_many(data)
            print(result.deleted_count, " documents deleted")
            if result.deleted_count != 0:
                return result
            else: 
                return "Error deleting"
        else:
            raise Exception("Nothing to read, because data parameter is empty")
            

        

#shelter = AnimalShelter('myUserAdmin', 'school')
#shelter.create({'name': 'dogShelter', 'numberOfAnimals': 16})
#update = shelter.update({'name': 'dogShelter', 'numberOfAnimals': 16}, {'$set': {'name': 'dogShelter', 'numberOfAnimals': 1}})
#print(update)
#print('updated')
#delete = shelter.delete({'name': 'dogShelter', 'numberOfAnimals': 1})
#print(delete)
#print('deleted')
